class Customer:
    #Customer class developed  for bank operations
    bank_name = 'Firstbit Bank'
    def __init__(self,name,balance=0.0):
        self.name = name
        self.balance = balance

    def deposit(self,amount):
        self.balance = self.balance + amount
        print("After depositing, Balance: ",self.balance)

    def withdraw(self,amount):
        if (self.balance < amount):
            print("Insufficient Fund....cannot perform this operation")
        else:
            self.balance = self.balance - amount
            print("After withdrawing, Balance: ",self.balance)
    
print("Welcome to",Customer.bank_name)
name = input("Enter Name: ")
c = Customer(name)

while True:
    print("d-deposit\nw-withdraw\ne-exit")
    choice = input("Choose your option: ")
    if(choice.lower()=='d'):
        amount = float(input("Enter Amount to deposit: "))
        c.deposit(amount)
    elif(choice.lower()=='w'):
        amount = float(input("Enter Amount to withdraw: "))
        c.withdraw(amount)
    elif(choice.lower()=='e'):
        print("Thank you for banking....")
        break
    else:
        print("Select valid option....")
